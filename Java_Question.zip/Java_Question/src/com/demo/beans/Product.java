package com.demo.beans;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Product implements Serializable{
	private int id;
	private String prod_name;
	private LocalDate exp;
	private String name;
	private int qty;
	private float price;
	public Product() {
		super();
	}
	public Product(int id, String prod_name, LocalDate exp, String name, int qty, float price) {
		super();
		this.id = id;
		this.prod_name = prod_name;
		this.exp = exp;
		this.name = name;
		this.qty = qty;
		this.price = price;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		
		Product other = (Product) obj;
		return this.id == other.id;
	}
	public Product(int id) {
		super();
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public LocalDate getExp() {
		return exp;
	}
	public void setExp(LocalDate exp) {
		this.exp = exp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", prod_name=" + prod_name + ", exp=" + exp + ", name=" + name + ", qty=" + qty
				+ ", price=" + price + "]";
	}
	
	
	
}
