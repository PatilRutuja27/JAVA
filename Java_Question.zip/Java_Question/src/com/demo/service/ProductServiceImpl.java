package com.demo.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.demo.beans.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {
	
	ProductDao pdao;
	public ProductServiceImpl(){
		pdao = new ProductDaoImpl();
	}
	@Override
	public boolean addNew() {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter id");
	int id =sc.nextInt();
	System.out.println("enter name");
	String name = sc.next();
	System.out.println("enter date of expiry");
	String exp = sc.next();
	System.out.println("enter quantity");
	int qty = sc.nextInt();
	System.out.println("enter price");
	float price = sc.nextFloat();
	System.out.println("enter salesman name");
	String sname = sc.next();
	LocalDate dt = LocalDate.parse(exp, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	
	Product p = new Product(id,name,dt,sname,qty,price);
	return pdao.addNew(p);
	
	}
	@Override
	public List<Product> displayAll() {
		
		return pdao.displayAll();
	}
	@Override
	public boolean deleteid(int id) {
		
		return pdao.deleteid(id);
	}
	@Override
	public void writeFile() {
		
		pdao.writeFile();
		
	}
	@Override
	public void readFile() {
		
		pdao.readFile();
		
	}
	@Override
	public List<Product> displayByName(String nm) {
		
		return pdao.displayByName(nm);
	}

}
