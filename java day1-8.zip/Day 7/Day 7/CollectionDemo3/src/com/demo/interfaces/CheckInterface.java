package com.demo.interfaces;

public interface CheckInterface<T>{
	T add(T x,T y);
	//String add(String x,String y);

}
