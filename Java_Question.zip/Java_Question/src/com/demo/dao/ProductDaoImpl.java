package com.demo.dao;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.demo.beans.Product;

public class ProductDaoImpl implements ProductDao {
	static List<Product> lst;
	static {
		lst = new ArrayList<>();
		//lst.add(new Product(1,"Maggie",LocalDate.of("07,07,2024"),"Abhay",34,34.0));
		
	}
	@Override
	public boolean addNew(Product p) {
		return lst.add(p);
		
	}
	@Override
	public List<Product> displayAll() {
		// TODO Auto-generated method stub
		return lst;
	}
	@Override
	public boolean deleteid(int id) {
		
		return lst.remove(new Product(id));
	}

	
	  @Override public void writeFile() {
	  
	 try(ObjectOutputStream oos = new ObjectOutputStream(new
	 FileOutputStream("OutputFile.txt"));) {
	 
	 for(Product p:lst) { oos.writeObject(p); }
	 
	 } catch (FileNotFoundException e) { // TODO Auto-generated catch block
	 e.printStackTrace(); }
	 catch (IOException e) { // TODO Auto-generated catch
	  e.printStackTrace(); }
	  }
	 
	@Override
	public void readFile() {
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("OutputFile.txt"));){
			
			while(true)
			{
				Product p=(Product)ois.readObject();
				lst.add(p);
			}
			
		} catch(EOFException e) {
			System.out.println("End of File");
		}
		catch (FileNotFoundException e) {
			
		
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public List<Product> displayByName(String nm) {
		List<Product> list = lst.stream()
				.filter(ob->ob.getName().equals(nm))
				.collect(Collectors.toList());
		if(list.isEmpty()) {
			return null;
		}
		return list;
	
	}

}
