package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

public class TestProduct {

	public static void main(String[] args) {
		ProductService pservice = new ProductServiceImpl();
		pservice.readFile();
		Scanner sc =new Scanner(System.in);
		int choice = 0;
		do {
		System.out.println("1.Add New Product 2.Display All 3.Delete Product 4.Search by salesman name 5.Search by price 6.exit");
		System.out.println("enter choice");
		choice = sc.nextInt();
		
		switch(choice){
		
		case 1:
			boolean status = pservice.addNew();
			if(status) {
				System.out.println("product added");
			}
			else {
				System.out.println("failed to add");
			}
		break;
		
		case 2:
			List<Product> list = pservice.displayAll();
			if(list!=null) {
				list.forEach(System.out::println);
				
			}
			else {
				System.out.println("not found");
			}
			break;
			
		case 3:
			System.out.println("enter id to be deleted");
			int id = sc.nextInt();
			status = pservice.deleteid(id);
			if(status) {
				System.out.println("id deleted");
			}
			else {
				System.out.println("id not found");
			}
			break;
			
		case 4:
			System.out.println("Enter Salesman Name :");
			String nm = sc.next();
			 List<Product> lst = pservice.displayByName(nm);
			 lst.forEach(ob->System.out.println(ob));
			
		case 6:
			pservice.writeFile();
			sc.close();
			System.out.println("Thank You!");
			break;
		}

	}while(choice!=6);
	}
}
