package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	boolean addNew();

	List<Product> displayAll();

	boolean deleteid(int id);

	void writeFile();

	void readFile();

	List<Product> displayByName(String nm);

}
