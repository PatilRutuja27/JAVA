
public class TestPersonArray1 {

	public static void main(String[] args) {
		Person[] parr=new Person[2];
		PersonService.addPersonData(parr);
		PersonService.displayPersonData(parr);

	}

}
