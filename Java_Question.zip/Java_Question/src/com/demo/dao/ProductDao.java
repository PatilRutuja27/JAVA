package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao {

	boolean addNew(Product p);

	List<Product> displayAll();

	boolean deleteid(int id);

	void writeFile();

	void readFile();

	List<Product> displayByName(String nm);

}
